export default function MeeshoAIGenerator() {
  const generatedImages = Array.from({ length: 10 });

  return (
    <div className="min-h-screen bg-gray-100 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="bg-black text-white rounded-3xl p-10 mb-8">
          <h1 className="text-5xl font-bold mb-4">Meesho AI Studio</h1>
          <p className="text-lg text-gray-300">
            Generate HD Meesho catalog images with low shipping optimization.
          </p>
        </div>

        <div className="bg-white rounded-3xl shadow-xl p-8 mb-8">
          <h2 className="text-3xl font-bold mb-6">AI Product Generator</h2>

          <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
            {generatedImages.map((_, index) => (
              <div
                key={index}
                className="aspect-square rounded-2xl bg-gray-200 flex items-center justify-center"
              >
                HD Image {index + 1}
              </div>
            ))}
          </div>

          <div className="mt-6 flex gap-4">
            <button className="bg-black text-white px-6 py-3 rounded-xl">
              Generate Images
            </button>

            <button className="bg-green-600 text-white px-6 py-3 rounded-xl">
              Export Meesho ZIP
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
