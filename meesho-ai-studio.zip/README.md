# Meesho AI Studio

## Run Instructions

1. Install Node.js
2. Create React app using Vite
3. Replace App.jsx with provided file
4. Run:

npm install
npm run dev

